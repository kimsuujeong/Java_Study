package Self_Study_01_02;

import java.util.Scanner;

class Schedule {

	private String work; // 하루의 할 일을 나타내는 문자열

	public void set(String work) {
		this.work = work;
	}

	public String get() {
		return work;
	}

	public void show() {
		if (work == null)
			System.out.println("없습니다.");
		else
			System.out.println(work + "입니다.");
	}
}

public class MonthSchedule {
	int month;
	Schedule[] day = null;
	Scanner sc = new Scanner(System.in);
	boolean isDay = true;
	int dayNum = 0;

	public MonthSchedule(int days) { //생성자 초기화
		dayNum = days;
		day = new Schedule[dayNum];

		for (int i = 0; i < day.length; i++) {
			day[i] = new Schedule();
		}
	}

	public void input() { // 입력 1
		System.out.print("날짜(1~30)?");
		int days = sc.nextInt();
		System.out.print("할일(빈칸없이입력)?");
		String work = sc.next();
		day[days].set(work);

	}

	public void view() { // 보기 2
		System.out.println(day+"일의 할 일은");
		day[dayNum].show();
	}

	public void finish() { // 끝내기 3
		System.out.println("프로그램을 종료합니다.");
		isDay = false;
	}

	public void run() {
		System.out.println("이번달 스케쥴 관리 프로그램.");
		while (isDay) {
			System.out.print("할일(입력:1, 보기:2, 끝내기:3) >>");
			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				input();
				break;
			case 2:
				view();
				break;
			case 3:
				finish();
				break;
			default:
				System.out.println("1~3 값을 입력해주세요");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		MonthSchedule april = new MonthSchedule(30);
		april.run();
	}
}
