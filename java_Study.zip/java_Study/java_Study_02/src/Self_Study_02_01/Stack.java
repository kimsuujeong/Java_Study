package Self_Study_02_01;

public interface Stack {

	int length(); // 현재 스택에 저장된 개수 리턴

	int capacity(); // 스택의 전체 저장 가능한 개수 리턴

	String pop(); // 스택의 톱(top)에 저장된 문자열 리턴

	boolean push(String val); // 스택의 톱(top)에 문자열 저장

}

class stack implements Stack {
	private int num; // 저장 가능한 개수
	private int set; // 저장 인덱스
	private String[] save; // 인덱스 저장

	public stack(int num, int set, String[] save) {
		super();
		this.num = num;
		this.set = set;
		this.save = save;
	}

	@Override
	public int length() { // 현재 스택에 저장된 개수 리턴
		// TODO Auto-generated method stub
		return num;
	}

	@Override
	public int capacity() { // 스택의 전체 저장 가능한 개수 리턴
		// TODO Auto-generated method stub
		return save.length;
	}

	@Override
	public String pop() { // 스택의 톱(top)에 저장된 문자열 리턴
		// TODO Auto-generated method stub
		if (set - 1 < 0) // stack에 아무 것도 넣지 않았을 때
			return null;
		set--;
		String s = save[set];
		return s;
		//
	}

	@Override
	public boolean push(String val) { // 스택의 톱(top)에 문자열 저장
		// TODO Auto-generated method stub
		return false;
	}

}