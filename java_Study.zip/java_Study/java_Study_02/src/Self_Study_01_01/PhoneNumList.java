package Self_Study_01_01;

import java.util.Scanner;

public class PhoneNumList {

	// 이름과 전화번호를 받아줄 scanner 생성
	private static Scanner scanner;

	// 정보를 smartPhone 객체에 저장
	SmartPhone telList[];

	public PhoneNumList() { // 생성자
		super();
		// TODO Auto-generated constructor stub
		scanner = new Scanner(System.in);
	}

	void sc() {
		// 인원수 받기
		System.out.println("인원수>>"); // 입력한 인원수
		int n = scanner.nextInt();

		telList = new SmartPhone[n]; // ☆ n담을 배열 생성

		for (int i = 0; i < n; i++) { // 입력한 인원수 만큼 출력
			// 이름과 전화번호 입력
			System.out.println("이름과 전화번호(이름과 번호는 빈 칸 없이 입력)>>");
			String name = scanner.next();
			String tel = scanner.next();

			telList[i] = new SmartPhone(name, tel);

		}

		System.out.println("저장 되었습니다..."); // 저장완료

	}

	// 검색기능
	String search(String name) {
		for (int i = 0; i < telList.length; i++) {
			if (telList[i].getName().equals(name)) {
				// Phone 클래스에 저장되어 있는 이름과 입력한 이름이 같으면 전화번호 리턴
				return telList[i].getTel();
			}
		}

		// 이름이 존재하지 않으면 null 리턴
		return null;
	}

	void manu() {
		sc();
		// 검색할 이름

		while (true) {// exit를 치면 프로그램 종료
			System.out.println("검색할 이름>>");
			String a = scanner.next();

			String tel = search(a);
			
			if (tel.equals(tel)) { // equals == 문자열인지 참인지 알려주는거
				// 문자열 a와 b가 같은지 비교할 때 a.equals(b)가 참인지로 판단

				System.out.println(a + "의 번호는");
				// 검색했는데 있으면 출력

			} else if (tel.equals(null)) {

				System.out.println(a + "(이)가 없습니다.");
				// 만약 검색 결과가 없으면 없다고 알리고 다시 입력

			} else if (tel.equals("exit")) {

				System.out.println("프로그램 종료");
				break;
			}
		}

	}

	public static void main(String[] args) {
		new PhoneNumList().manu();
	}
}
