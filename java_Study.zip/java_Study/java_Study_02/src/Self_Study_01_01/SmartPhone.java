package Self_Study_01_01;

public class SmartPhone {
	
	private String name; // 이름
	private String tel; // 전화번호
	
	public SmartPhone(String name, String tel) { //생성자
		super();
		this.name = name;
		this.tel = tel; 
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}


}
