package 추석선물세트;

public class Chusuck {
	
	void Text(){
		
		
	}
	
	public static void main(String[] args) {
		
		System.out.println("1"+2);
		
	}

}
