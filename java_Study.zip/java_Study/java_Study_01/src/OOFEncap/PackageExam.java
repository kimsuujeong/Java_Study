package OOFEncap;

public class PackageExam {
	public static void main(String[] args) {
		// 패키지 : 연관된 것들 끼리의 고유공간
		// 모듈 : 파일 하나 .( 클래스 하나)
	}

}
