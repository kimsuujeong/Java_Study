package Oop_Review4;

public interface Discounttable {
	
	void applyDiscount(double discountPercent);

	double getPrice(double percet);
	

}
