package Oop;

public class umm {
	// 어떻게 사람 이름이
	// 엄
	// 준
	// 식
	// 사람 이름이 어떻게 그러냐 ㅋㅋㅋㅋㅋ
	String What_Name = "어떻게 이름이?";
	String First_Name = "엄";
	String Middle_Name = "준";
	String Last_Name = "식?ㅋ";
	String what_umm = ("어떻게 사람 이름이 그러냐?ㅋㅋㅋㅋ");


	public void What_um() {

		System.out.println("뭐라고요? 어떻게 사람 이름이 엄ㅋㅋㅋㅋㅋ");

	}
	
	public void Where_umm() {
		
		System.out.println("동탄에 사는 엄.........");
		
	}
	
	public void final_umm () {
		
		System.out.println("어떻게 사람 이름이 ㅋㅋㅋㅋ 엄 ㅋㅋㅋㅋㅋㅋ");
	}
	
}
