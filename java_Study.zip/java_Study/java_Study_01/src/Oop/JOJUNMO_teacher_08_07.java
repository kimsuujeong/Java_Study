package Oop;

public class JOJUNMO_teacher_08_07 {
	
	String name = "JOJUNMO";
	String question = "질문은 여러분들의 권!리! 입니다!";
	String week_Test = "내고 싶지만 ㅂㄷㅂㄷ";
	String gunchimi = "군치미 돕니다";
	String today_mood = "군침이 회모리치노!!!!";

	public void paata() {
		
		System.out.println("or 멍석말이");
		
	}
	public void age() {
		
		System.out.println("띠동갑 입니둥");
	
	}
	public void like() {
		
		System.out.println("이렇게 하면 암바를 걸겠습니다");
		
	}
	public void student() {
		
		System.out.println("여러분이 괴로워하는 것을 보면 군침이 싹~");
		
	}

}
