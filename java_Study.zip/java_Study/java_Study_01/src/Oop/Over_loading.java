package Oop;

public class Over_loading {
	public static void main(String[] args) {
		
		Student kmove12th5 = new Student ("닛본삘");
		
		
		
	}
}
