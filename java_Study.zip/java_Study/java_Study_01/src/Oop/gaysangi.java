package Oop;

public class gaysangi {

	public static int add(int a, int b) {

		return a + b;

	}

	public static int sub(int a, int b) {

		return a < b ? b - a : a - b;
		
	}

	public static int nanugi(int a, int b) {

		return a / b;

	}
}