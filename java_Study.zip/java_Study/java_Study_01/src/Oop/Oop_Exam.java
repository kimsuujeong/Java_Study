package Oop;

public class Oop_Exam {
	public static void main(String[] args) {
		// 객체 : 현실세계에 존재하는 물질
		// 객체들은 속서오가 행동을 가지고 있음
		
		// 프로그래밍 세계의 객체
		
		// 컵, 컴퓨터, 학교, 강아지
		
		umm ummm = new umm();
		
		System.out.println(ummm.What_Name);
		
		ummm.What_um();

	
	}
	class Name{
		
		String What_Name = "어떻게 이름이?";
		String First_Name = "엄";
		String Middle_Name = "준";
		String Last_Name = "식?ㅋ";
		
		public void What_um(){
			
			System.out.println("어떻게 사람 이름이 그러냐?ㅋㅋㅋㅋ");
			
		}
		
		public void Where_um() {
			
			System.out.println("뭐라고요? 어떻게 사람 이름이 엄ㅋㅋㅋㅋㅋ");
			
		}
		
	}
}
