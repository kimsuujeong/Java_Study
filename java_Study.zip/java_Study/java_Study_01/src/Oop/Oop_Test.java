package Oop;


public class Oop_Test {
	
	public static void main(String[] args) {
		
		int test = gaysangi.add(10, 20);
		System.out.println(test);
		
	}

}
