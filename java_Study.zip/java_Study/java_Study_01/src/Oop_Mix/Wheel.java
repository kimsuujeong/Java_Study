package Oop_Mix;

public class Wheel {
	
	String shape;
	String material;
	double size;
	
	public void rolling() {
		
		System.out.println("앞으로구루기");
		
	}
	public void stop() {
		
		System.out.println("스토루");
		
	}
	public void backRolling() {
		
		System.out.println("뒤로 가요오옷");
		
	}

}
