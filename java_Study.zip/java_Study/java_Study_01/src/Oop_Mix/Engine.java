package Oop_Mix;

public class Engine {
	
	// 속성 : 기름종류, 가동률, cc
	// 행동 : 동작, 정지
	
	String oilType;
	double gadonglyul;
	int displacement;
	
	public void move(String[] args) {
		
		System.out.println("움직여요오옹");
		
	}
	public void stop(String[] args) {
		
		System.out.println("멈춰요오옹");
		
	}

}
