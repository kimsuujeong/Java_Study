package Oop_Mix;

public class Handle {

	String material;
	String shape;
	
	public void turnRight() {
		
		System.out.println("오른쪽으로 가유");
		
	}
	public void Turnleft() {
		
		System.out.println("왼쪽으로 가유웅");
		
	}
	public void bbangbbang() {
		
		System.out.println("하야끄 하야끄");
		
	}
	
}
