package Oop_Mix;

public class Car {
	
	String name;
	Engine engline;
	Handle handle;
	Wheel wheel;
	
	public Car(String name, String string, String string2, String string3) {
		super();
		this.name = name;
		this.engline = string;
		this.handle = string2;
		this.wheel = string3;
	}
	
	
	
	

}
