package Oop_Review;

public class Main {
	
	public static void main(String[] args) {
		
		NotePadService nps = new NotePadService(); 

		nps.run();

		
		/* 과제
		 * 1. 수정 구현하기
		 * 2. 전체보기에서 이상한 점을 찾고
		 * 이상한 점 수정할 방법을 알아오기*/
	}
}
