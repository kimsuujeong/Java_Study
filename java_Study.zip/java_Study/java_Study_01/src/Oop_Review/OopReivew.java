package Oop_Review;

public class OopReivew {
	
	private int noteLength = 0 ;
	private final NoteEntitiy[] wtf;
	private final int NOTE_SIZE = 50;
	
	public OopReivew() {
		
		this.wtf = new NoteEntitiy[NOTE_SIZE];
				
	}
	
	public void addTEXT() {
		
	}
	
}
