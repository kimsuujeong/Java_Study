package Oop_Extend;

public class Car {
	
	public void run() {
		
		System.out.println("ㅈㄴ 달리노");
		
	}
	
}
