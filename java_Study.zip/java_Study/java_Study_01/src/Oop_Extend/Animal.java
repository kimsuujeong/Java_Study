package Oop_Extend;

public class Animal {
	
	String typel;

}
