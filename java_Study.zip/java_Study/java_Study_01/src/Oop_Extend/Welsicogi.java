package Oop_Extend;

public class Welsicogi extends Dog {

	public Welsicogi(String naem, int weight) {
		super(naem, weight);
		// TODO Auto-generated constructor stub
	}

	

}
