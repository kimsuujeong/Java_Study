package Oop_Extend;

public class Porche extends Car{
	
	@Override /**기능이 있는 주석임*/
	public void run() {
		
		System.out.println("ㄲ요옹옹ㅅ ㅈㄴ 나가노 !!");
		
	}
}
