package Oop_Extend;

public class Dog {
	
	String naem;
	int weight;
	
	public Dog(String naem, int weight) {
		super();
		this.naem = naem;
		this.weight = weight;
	}
	public void how() {
		
		System.out.println("나 짖 개");
		
	}
	public void jealong() {
		
		System.out.println("미친놈아 놀아주 개");
		
	}
	public void eat() {
		
		System.out.println("나 먹 개");
		
	}

}
