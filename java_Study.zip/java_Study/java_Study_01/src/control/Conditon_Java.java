package control;

public class Conditon_Java {

	public static void main(String[] args) {
		if (조건식) {
			// 조건식이 참일 경우 실행되는 영역
		} else if (조건식) {
			// if가 거짓이면서 else if 조건식이 참인 경우
			// 실행되는 영역
		} else {
			// if와 else if가 모두 거짓이면 실행되는 영역
		}
		
		System.out.println();

	}

}
