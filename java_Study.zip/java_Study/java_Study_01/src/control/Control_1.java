package control;

public class Control_1 {
	public static void main(String[] args) {
		// 제어문
		// 프로그램의 순차적인 흐름을 제어하기 위한 문법(명령문)
		// 제어문에는 조건문과 반복문이 있다.
		
		
	}
}
