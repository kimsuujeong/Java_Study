package control;

public class ramen_Recipe {

	public static void main(String[] args) {
		// 1. 물을 넣고 스프와 건더기를 넣는다.
		// 물, 스프, 건더기를 어떻게 표현할까?
		// 물 : 리터 단위니까 문자로 해도 숫자로 해도 상관 없을 듯
		// 스프: 표현하기가 애매함. (T/F)
		// 건더기 : 마찬가지로 표현이 애매 함! T/F 표현
		
		int
		// 2. 끓을 때 까지 기다린다.
		// 3. 끓으면 면과 계란을 넣는다.
		// 4. 먹으면 군침이 싹 도노

	}

}
