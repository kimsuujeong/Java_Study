package java_Basic;

public class ConstExam {

	public static void main(String[] args) {
		
		

	}

}
