package java_Basic;

import java.util.Scanner;

public class Basic {

	public static void main(String[] args) {
		
		//System.out.println("안녕 자바야 안녕안녕");

		//System.out.println("점심먹고 나니 개졸렵넹");
		//System.out.println("난 둘다 어려움...ㅡㅡ");
		
		Scanner sc = new Scanner(System.in);
		System.out.println("아무거나 입력해 보세용");
		sc.nextLine();
		

	}
}