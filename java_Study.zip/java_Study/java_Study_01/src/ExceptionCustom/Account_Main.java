package ExceptionCustom;

public class Account_Main {
	
	public static void main(String[] args) {
	
	}
	
}
