package Sujeong_quiz5;

public class Person implements Enrollable {
	
	String name;
	String email;
	
	public Person(String name, String email) {
		super();
		this.name = name;
		this.email = email;
	}
	
	private void enroll() {
		// TODO Auto-generated method stub
		System.out.println("[" + name + "을(를) 수강 등록합니다.");
		

	}
	

}
