package Sujeong_quiz5;

public class Student extends Person{
	
	int studentID;

	public Student(String name, String email, int studentID) {
		super(name, email);
		this.studentID = studentID;
	}
	
	
	
}
