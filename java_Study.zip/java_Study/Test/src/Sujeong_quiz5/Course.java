package Sujeong_quiz5;

import java.util.List;

public class Course {
	
	String courseName;
	
	Instructor instructor = new Instructor(); 
	List students;
	
	public Course(String courseName, Instructor instructor1, List students) {
		super();
		this.courseName = courseName;
		this.instructor1 = instructor1;
		this.students = students;
		
		
	}
	
	
	
	
	

}
