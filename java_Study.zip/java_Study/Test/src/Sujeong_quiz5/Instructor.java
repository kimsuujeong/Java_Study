package Sujeong_quiz5;

public class Instructor extends Person {
	
	String expertis;
	
	public Instructor() {
		// TODO Auto-generated constructor stub
	}

	public Instructor(String name, String email, String expertis) {
		super(name, email);
		this.expertis = expertis;
	}



}
