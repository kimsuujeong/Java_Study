package Sujeong_quiz5;

public interface Enrollable {

}
