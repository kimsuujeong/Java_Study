package Test_08_25;

public class Building  {
	
	static String name;
	static int capacity;
	
	public Building() {
		
	}
	
	public Building(String name, int capacity) {
		super();
		this.name = name;
		this.capacity = capacity;
	}
	
	public static void getDescription() {
		return;
	}
	

}