package Test_08_25;

public class Park extends Building {

	Building building = new Building();
	
	@Override
	public static void getDescription() {
		return;
	}
	
}