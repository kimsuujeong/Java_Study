package Test_08_25;

public class School extends Building{
	
	

}
