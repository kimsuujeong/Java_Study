package Big_Test_01;

public class Sujeong_quiz1 {

	public static String zu_sujeong(String string) {

		String result = "";
		
		return result = string.substring(string.length()-3, string.length());

	}

	public static void main(String[] args) { // test case

		String sentence1 = "이번 프로젝트는 메챠쿠챠 하군요";
		String sentence2 = "오마에와 모 신 데이루";
		System.out.println("문장: " + sentence1);
		System.out.println("숨겨진 단어: " + zu_sujeong(sentence1));
		System.out.println("문장: " + sentence2);
		System.out.println("숨겨진 단어: " + zu_sujeong(sentence2));
		
	}

}

