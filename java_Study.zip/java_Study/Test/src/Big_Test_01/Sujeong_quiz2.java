package Big_Test_01;

import java.util.Random;
import java.util.Scanner;

public class Sujeong_quiz2 {

	public static void main(String[] args) {

		// 필요한 동전 입력받기
		System.out.println("보물상자 금액 입력: ");

		Scanner sc = new Scanner(System.in);
		int coin = sc.nextInt();

		// 동전 종류와 가치 정하기
		Random random = new Random();

		int num = random.nextInt(1,4); //10,50,100,500

		int money = (int) (num * 50);
		int[] coins = { 500, 100, 50, 10 };
		
		// 최소한의 개수로 금액을 거슬러 줘야함
		for (int i = 0; i < coins.length; i++) {
			int count = money / coins[i];
			System.out.println(money);
			money = money % coins[i];
			System.out.println(money);
			System.out.println(coins[i] + "원 :" + count + "개");


		}

	}
}
