package Test_08_29;

public class PowerNoise {
	static String title;
	static String artist;
	static int year;
	static String country;

	public PowerNoise() {

	}

	public PowerNoise(String title, String artist, int year, String country) {
		super();
		this.title = title;
		this.artist = artist;
		this.year = year;
		this.country = country;
	}
	
	// 노래 정보 출력
	public static void show() {

		System.out.println(year+"년 " + country + "국적의 " + artist + "가 부른" + title);
		

	}
	
	public static void main(String[] args) {
		
		PowerNoise Song = new PowerNoise("화려한 군침이", "군침이", 2015, "대한민국");
		
		Song.show();
		
		
	}

}
