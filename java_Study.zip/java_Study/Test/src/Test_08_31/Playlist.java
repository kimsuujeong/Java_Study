package Test_08_31;

import java.util.ArrayList;
import java.util.List;

public class Playlist{
	/*
	 * private List<Playable> mediaList = new ArrayList<>();
	 * 
	 * pyblic void addMedia(Playable media) {
	 * 	mediaList.add(media);
	 * }
	 * 
	 * public void playAll() {
	 * for (Pllayable media : mediaList) {
	 * media.play();
	 * }
	 * }
	 * 
	 * */
	
	private List<Playable> mediaList = new ArrayList<>();
	
	public void addMedia(Playable media) {
		
	}
	
	public void playAll() {
		
	}
	


}
