package Test_08_31;

public class Audio implements Playable {
	
	String title;
	String artist;
	
	public Audio() {
		
	}
	
	public Audio(String title, String artist) {
		super();
		this.title = title;
		this.artist = artist;
	}

	@Override
	public void play() {

		System.out.println(artist + " 의" + title +" 곡을 재생합니다.");
		
	}

}
