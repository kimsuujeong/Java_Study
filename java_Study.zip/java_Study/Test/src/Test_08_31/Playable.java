package Test_08_31;

public interface Playable {
	
	void play();

}
