package Test_08_31;

public class Video implements Playable {
	
	String title;
	String duration;
	
	public Video(String title, String duration) {
		super();
		this.title = title;
		this.duration = duration;
	}

	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println(title + " 영상을 재생합니다." + "(길이 :" + duration + "초)");
		
	}

	

}
