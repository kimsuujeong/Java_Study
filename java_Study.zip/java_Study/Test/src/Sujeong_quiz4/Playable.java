package Sujeong_quiz4;

public interface Playable {
	
	/*이 인터페이스는 
	 * 음악을 재생하는 메서드를 가지며, 
	 * 음악 뿐만 아니라 다양한 미디어를 처리하는 데 
	 * 사용됩니다.*/
	void play();

}
