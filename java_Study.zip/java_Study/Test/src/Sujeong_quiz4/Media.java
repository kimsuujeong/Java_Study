package Sujeong_quiz4;

public class Media implements Playable{
	static /*이 클래스는 Playable 인터페이스를 구현하며, 
	 * 음악과 관련된 공통 정보와 동작을 가집니다.*/
	
	String title;
	int duration;
	
	public Media(String title, int duration) {
		super();
		this.title = title;
		this.duration = duration;
	}
	
	@Override
	public void play() {
		System.out.println("[" + title + "] 을(를) 재생합니다");
	}
	
	

}
