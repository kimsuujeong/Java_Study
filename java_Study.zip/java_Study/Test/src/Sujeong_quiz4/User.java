package Sujeong_quiz4;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class User {
	
	String username;
	Set<String> followedArtists = new HashSet<String>();
	List subscribeMusic;
	
	
	
	public void followArtist(String artistName) {
		
	}
	
	public void subscribeMusic(Music music) {
		
	}
	
	public void listenMusic() {
		
	}

}
