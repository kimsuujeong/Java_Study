package Sujeong_quiz4;

public class Music extends Media{
	
	/*음악에 대한 추가 정보를 가집니다*/
	
	String artist;
	String genre;
	
	public Music(String title, int duration, String artist, String genre) {
		super(title, duration);
		this.artist = artist;
		this.genre = genre;
	}
	
	

}
