package Test_08_24_2;

public class Character {
	
	String name;
	int level;
	
	public static void attack() {
		System.out.println("일반 공격!!");
	}

	public Character(String name, int level) {
		super();
		this.name = name;
		this.level = level;
	}

}
