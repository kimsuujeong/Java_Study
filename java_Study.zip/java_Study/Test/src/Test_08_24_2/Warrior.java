package Test_08_24_2;

public class Warrior extends Character{

	public Warrior(String name, int level) {
		super(name, level);
		// TODO Auto-generated constructor stub
	}
	
	public static void swingSword() {
		System.out.println("검으로 휘두룸!");
	}

}
