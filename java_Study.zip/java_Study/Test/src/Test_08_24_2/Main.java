package Test_08_24_2;

public class Main{
	
	static Warrior Character1 = new Warrior("엄준식", 132);
	static Warrior Character2 = new Warrior("군치미", 22);
	static Mage Character3 = new Mage("최종보스 김수정", 999999);
	


	public static void main(String[] args) {
		
		System.out.print(Character1.name);
		System.out.print(" ");
		System.out.print(Character1.level);
		System.out.print(" ");
		Character1.attack();
		
		System.out.print(Character2.name);
		System.out.print(" ");
		System.out.print(Character2.level);
		System.out.print(" ");
		Character3.castSpell();
		
		System.out.print(Character3.name);
		System.out.print(" ");
		System.out.print(Character3.level);
		System.out.print(" ");
		Character2.swingSword();
		
		
	}

}
