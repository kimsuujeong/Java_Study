package Test_08_24_2;

public class Mage extends Character {
	
	
	public Mage(String name, int level) {
		super(name, level);
		// TODO Auto-generated constructor stub
	}
	
	public static void castSpell() {
		System.out.println("마법 시전!");
	}
	
	

}
