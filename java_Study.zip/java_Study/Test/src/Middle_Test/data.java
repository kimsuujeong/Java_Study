package Middle_Test;

public class data {
	
	String name;
	String hint;
	
	public data(String name, String hint) {
		super();
		this.name = name;
		this.hint = hint;
	}
	
}
