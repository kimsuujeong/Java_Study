package Middle_Test;

public class Exam_2 {
	public static void main(String[] args) {
		
	}
	
	public static void treasure() {
		
	}
	
	
}
