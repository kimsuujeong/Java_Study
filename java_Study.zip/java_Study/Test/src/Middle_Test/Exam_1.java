package Middle_Test;

import java.util.HashMap;

import java.util.Random;

import java.util.Scanner;

public class Exam_1 {

	public static void main(String[] args) { // 사전에 정의된 단어들 입력, 힌트를 리스트로 저장
		HashMap<Integer, data> map = new HashMap<Integer, data>();

		// 데이터 입력

		map.put(1, new data("짜장면", "검은 면이 쳐 즥이네!"));

		map.put(2, new data("마라탕", "잼민이들이 좋아하는 얼큰한 중국 샤브샤브 쳐 즥이네!"));

		map.put(3, new data("헴버거", "참깨빵 위에 순쇠고기 패티 쳐 즥이네!"));

		map.put(4, new data("치킨", "바삭한 닭이 쳐 즥이네!"));

		map.put(5, new data("국밥", "뜨끈하고 든든한게 쳐 즥이네!"));

		map.put(6, new data("떡볶이", "떡과 고추장 조합 쳐 즥이네!"));

		// 랜덤함수를 통해 정답 지정

		Random random = new Random();

		int num = random.nextInt(7);

		Scanner sc = new Scanner(System.in);
		System.out.println("<<< 단어 맞추기 게임 >>>");

		System.out.println(" 흰트 나가노!!!!! ");

		System.out.println(map.get(num).hint);

		System.out.println("---------------------");

		System.out.println("정답 입력해주개!!");

		// 반복문

		while (true)

		{

			// 사용자의 값을 입력받고

			String userInput = sc.nextLine();

			// 정답인지 체크

			if (map.get(num).name.equals(userInput)) {// 정답일경우?

				System.out.println("맞췄노!!!!");

				break;

			} else if (userInput.equals("끝내!")) {

				System.out.println("잘가시개!!");

				break;

			} else {

				System.out.println("좀 더 분발 하시 개!!!!!!!!!!!!!!!!!!!!!!");

				System.out.println("[끝내!] 라고 하면 끝남");

			}
		}
	}
}