package Test_08_24_1;

public class Vehicle {

	static int speed;

	public Vehicle(int speed) {
		super();
		this.speed = speed;
	}
	//주어진 값[increment]만큼 기존의 속도[speed]를 증가시키는 함수 
	public static void accelerate(int increment) {
		
		speed += increment;
		
	}	
	
	
}
