package Test_08_24_1;

public class Main {
	
	public static void main(String[] args) {
		
		Covertible cars = new Covertible(130, "아무거나");
		cars.accelerate(130);
		cars.openRoof();
		
		System.out.println(cars.toString());
	}

}
