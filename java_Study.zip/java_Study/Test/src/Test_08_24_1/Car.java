package Test_08_24_1;

public class Car extends Vehicle {
	
	String brand;
	
	public Car(int speed,String brand) {
		super(speed);
		this.brand = brand;
		// TODO Auto-generated constructor stub
	}

	public String getBrand() {
		
		return brand;
		
	}
	
	public String toString() {
		
		return "브랜드: ["+ brand + "], 속도: [" + speed + "]";
		
	}
	

}
