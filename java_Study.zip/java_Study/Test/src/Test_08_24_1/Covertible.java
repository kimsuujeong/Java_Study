package Test_08_24_1;

public class Covertible extends Car {

	static boolean roofOpen;

	public Covertible(int speed, String brand) {
		super(speed, brand);
		// TODO Auto-generated constructor stub
	}

	public static void openRoof() {

		roofOpen = true;

	}

	public static void closeRoof() {

		roofOpen = false;

	}

	@Override

	public String toString() {

		return "브랜드: [" + brand + "], 속도: [" + speed + "], 루프상태: [" + roofOpen +"]";

	}

}
