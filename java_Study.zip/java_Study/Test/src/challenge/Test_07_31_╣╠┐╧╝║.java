package challenge;

public class Test_07_31_미완성 {
	private static int INF;


	public static void jolra_Ssan_nom_2_2im(int n, int results) {

		// 선수 n 경기 결과 [jolra_Score] -> 2차원 배열 results
		
		// n명의 선수 1~n 번호 1명 부터 100명 이하임
		
		// 경기 결과는 1~4500 이하임
		long game;
		// result 배열은 각 행 [A, B]는 선수 A선수가 B를 이겼다는 소리
		int jolra_win[][]; // 이김
        boolean adj[][];
        int jolra_loser[][]; //졌음
		
		// floyd-warshall 알고리즘 (O(n^3))
        
		//갚을 초기화 해주는 알고리즘 BUT 무슨 말인지 모룸 해석 드가자드가자!!
		for(int i = 1; i<=n; i++){
		    for(int j =1; j<=n; j++){ //n 선수 까지
		        if (i == j) jolra_win[i][j] = 0; //졸라 이김
		        else jolra_loser[i][j] = INF; //졸라 짐
		    }
		}

		for(int k = 1; k<= n; k++){
		    for(int i = 1; i <= n; i++){
		        for(int j = 1; j<=n; j++){
		            if(jolra_win[i][k] == 1 && jolra_loser[k][j] == 1) {
		                jolra_win[i][j] = 1;
		                jolra_loser[j][i] = -1;
		            }
		        }
		    }
		}
	}


	public static void main(int[] agrs, int i, int j) {
		@SuppressWarnings("unused")
		int n = 5; // 선수 수는 5명

		System.out.println(n + "results" + "return");

//		입출력 예
//		n	results	return
//		5	[[4, 3], [4, 2], [3, 2], [1, 2], [2, 5]]	2
//		입출력 예 설명
//		2번 선수는 [1, 3, 4] 선수에게 패배했고 5번 선수에게 승리했기 때문에 4위입니다.
//		?> ?> ?> 2> 5
//		4>3>2
//		5번 선수는 4위인 2번 선수에게 패배했기 때문에 5위입니다.

	}
}
