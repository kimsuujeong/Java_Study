package challenge;

public class Test_08_03_1 {
	public static void main(String[] args) {

		// 고속도로를 이동하는 차랑의 경로 -> routes;
		long routes;
		// 단속카메라 최소의 갯수 jeol_dea_ann_nochim
		int jeol_dea_ann_nochim;
		// 차량은 1대 이상 10,000대 이하
		int car = 1;

		// reoutes에는 차량의 이동 경로가 포함 되어 있음
		long reoutes;
		
		// routes[i][0]에는 i 번째 차량이 고속도로에 진입한 지점,
		// routes[i][1]에는 i 번째 차량이 고속도로에서 나간 지점

		// 차량의 진입/ 지출 지점에 카메라가 설치되어 있어도 카메라를 만난 것으로 간주
		// 차량의 진입 지점, 진출 지점은 -30,000 이상 30,000 이하
		int welcome_Car;
		int bye_Car;
		

//				routes	return
//						[[-20,-15], [-14,-5], [-18,-13], [-5,-3]]	2
//						입출력 예 설명

		// -5 지점에 카메라를 설치함 두 번째, 네 번째 차량이 카메라를 만난다.
		// -15 지점에 카메라를 설치하면 첫 번째, 세 번째 차량이 카메라를 만난다.
		
		
	}

	public static void jolra_farla(String[] args) {

	}

}
