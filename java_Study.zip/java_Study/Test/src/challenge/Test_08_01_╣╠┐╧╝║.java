package challenge;

import java.util.PriorityQueue;

public class Test_08_01_미완성 {

	public static String pororobus(int n, int t, int m, String timetable[]) {

		// 셔틀은 09:00부터 n회 t간격으로 운영 된다.
		// 하나의 셔틀 안에는 m명의 승객이 탈 수 있다.
		// 셔틀 운행은 n
		int pororobus = n;
		// 셔틀 운행 간격은 t
		int pororobustime = t;
		// 한 셔틀에 탈 수 있는 최대 친구 수 m
		int pororo_Friend = m;

		// 자리가 있으면 버스가 출발할 때 와서 탄다
		// 자리가 없으면 제일 말지막에 타는 사람 보다 1분 먼저 와서 탄다
		PriorityQueue<Integer> pq = new PriorityQueue<>(); // 낮은 숫자가 우선순위가 높은 방식

		// 친구가 대기열에 도착하는 시간을 모은 배열 timetable
		// *** timetable = 1~2000배열
		// 굳이 배열로 할 필요가...????

		int hi_Bus = 9 * 60; // 오후 9시
		int bye_Bus = 0;

		
		return hi_Bus + ":" + bye_Bus;
	}
	// HH:MM -> 하루동안 친구들이 대기열에 도착하는 시간 (09:00~23:59)

	public static void main(String[] args) {

		// 0 ＜ n ≦ 10
		// 0 ＜ t ≦ 60
		// 0 ＜ m ≦ 45

		System.out.println("n t m timetable");
		System.out.println();


	}
}
