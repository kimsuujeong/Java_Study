package Sujeong_quiz3;

public class Main {
	
	private void TextAnalyzer() {
		// TODO Auto-generated method stub
		
		ResultPrinter.getMostFrequentWord();
	}

}
