package Sujeong_quiz3;

public class TextAnalyzer {
	
	/* 
	 * 이 클래스는 텍스트를 입력받아 단어의 출현 빈도를 계산하고, 
	 * 가장 자주 출현하는 단어를 반환하는 기능을 가지고 있습니다.*/

	public static void analyze(String text) { // 입력된 텍스트를 분석하여 단어의 출현 빈도 정보를 계산

	}

	public static void getMostFrequentWord() {// 가장 자주 출현하는 단어를 반환합니다.

	}

}
