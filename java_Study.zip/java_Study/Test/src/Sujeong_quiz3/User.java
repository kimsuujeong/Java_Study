package Sujeong_quiz3;

import java.util.List;

public class User {
	
	String username;
	String followedArtists;
	List subscribeMusic;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getFollowedArtists() {
		return followedArtists;
	}
	public void setFollowedArtists(String followedArtists) {
		this.followedArtists = followedArtists;
	}
	public List getSubscribeMusic() {
		return subscribeMusic;
	}
	public void setSubscribeMusic(List subscribeMusic) {
		this.subscribeMusic = subscribeMusic;
	}
	

}
