package Sujeong_quiz3;

public class ResultPrinter extends TextAnalyzer{
	
	/*
	 * 이 클래스는 TextAnalyzer로부터 
	 * 계산된 결과를 출력하는 역할을 수행합니다.
	 * */
	
	private void printResult(String mostFrequentWord) {
		// TODO Auto-generated method stub

	}

}
