package general;

public class Test_08_12 {
	
	public static String solution(String Str) {

		String answer = "";
		char[] arry = Str.toCharArray();

		for (int i = 0; i < arry.length; i++) {

			String temp = arry[i] + "";
			
			// 아스키 코드로 소문자는 97(a)부터 122(z)까지임
			answer = arry[i] >= 97 && arry[i] <= 122 ? (answer += temp) : (answer += temp);

		}
		
		return answer;
		
	}

	public static void main(String[] args) {

		String abcd = "aBcDeFg";

		System.out.println(solution(abcd));
	}
}