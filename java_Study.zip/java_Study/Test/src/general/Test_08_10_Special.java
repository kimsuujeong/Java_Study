package general;

import java.text.DecimalFormat;

public class Test_08_10_Special{
	
	static double base = 5.0;
	static double height = 3.5;
	
	double getArea(){ // 삼각형 넓이
		
		return base* height / 2 ;
	}
	
	
	static double getHypotenuse() { // 및변 길이
		
		return Math.sqrt(base*base+height*height); // 제곱근 반환
		
	}
	
	static double getPrimeter() { // 둘레 길이
		
		
		return base + height + getHypotenuse();
		
	}

	public static void main(String[] args) {
		
		Test_08_10_Special ob = new Test_08_10_Special();
		
		DecimalFormat df = new DecimalFormat("0.00");
		
		System.out.println("삼각형의넓이: " + ob.getArea());
		System.out.printf("빗면의길이: " + df.format(getHypotenuse()));
		System.out.printf("\n둘레 길이: "+ df.format(getPrimeter()));
		
	}

}
