package general;


public class Test_08_10 {
	

	public static Object hello_world(String n_bun_nabok, int n) {
		
        String answer = "";
        
        char[] arr = n_bun_nabok.toCharArray();
        
        for(int i=0;i< n_bun_nabok.length();i++) {
            for(int j=0;j<n;j++) {
                answer += arr[i];
            }
        }
        return answer;
	}
		
	public static void main(String[] args) {

		int n = 3;
		String n_bun_nabok = "helloworld";
		
		
		System.out.println(hello_world(n_bun_nabok,n));

	}
}