package general;

import java.util.ArrayList;
import java.util.List;

public class Test_08_18 {

	
	public static List<Integer> egun_mosam(int a,int b,int n) {
		
		List<Integer> su_ya = new ArrayList<>();
		
		for(int i = a; i <= n + 1; i++) {
			
			su_ya.add((i - 1) * b);
			
		}
		
		return su_ya;
	
	}
	
	public static void main(String[] args) { // test case
		
		System.out.println("a   b   n   answer");
		System.out.println("2   2   5   " + egun_mosam(2, 2, 5));
		
	}
}
