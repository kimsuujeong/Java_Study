package general;

public class Test_08_01_2 {

	public static void main(String[] args) {
		
		int money = 53130;

		System.out.println("만원 = "+(money/10000));
		System.out.println("천원 = "+ (money%10000/1000));
		System.out.println("백원 = "+ (money%1000/100));
		System.out.println("십원 = "+ (money%100/10));
		
		int givon = 1500000;
		int sudang = 55000;
		int segold = 10;
		
		int sum = givon+sudang;
		
		System.out.println("실수령액 : " + (sum-(givon/segold)));
		
		
	}
}
