package general;

import java.util.Scanner;

public class Test_08_03_2 {
	public static void main(String[] args) {
//		int year;

//		@SuppressWarnings("resource")
//		Scanner sc = new Scanner(System.in);
//		System.out.println("년도를 입력 하세요: ");
//		year = sc.nextInt();
//
//		if ((year % 4) == 0 && (year % 100) != 0 || (year % 400) == 0) {
//			System.out.println("윤년");
//		} else {
//			// if와 else if가 모두 거짓이면 실행되는 영역
//			System.out.println("평년");
//		}

		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("중간고사를 입력하시오:");
		int middlego4 = sc.nextInt();
		System.out.println("기말고사를 입력하시오:");
		int gihorsgo4 = sc.nextInt();
		System.out.println("레포트고사를 입력하시오:");
		int reportgo4 = sc.nextInt();
		System.out.println("출석고사를 입력하시오:");
		int higo4 = sc.nextInt();
		
		System.out.println("중간고사: "+ middlego4);
		System.out.println("기말고사: "+ gihorsgo4);
		System.out.println("레포트고사: "+ reportgo4);
		System.out.println("출석고사: "+ higo4);
		
		
		double score = (middlego4+gihorsgo4)/2 * 0.6 + reportgo4 * 0.2 + higo4 * 0.2;
		
		if (score >= 90 || score >=80) {
			System.out.println("성적 = " + score);
			char result = (score >= 90 || score >=80 ? 'A':'B');
			System.out.println("학점 = " + result);
			System.out.println("평가 = excellent");
			
		} else if(score >= 70 ||
				score >= 60) {
			System.out.println("성적 = " + score);
			char result = (score >= 90 || score >=80 ? 'C':'D');
			System.out.println("학점 = " + result);
			System.out.println("평가 = good" + score);
			
		} else {
			System.out.println("성적 = " + score);
			System.out.println("학점 = " + "F");
			System.out.println("평가 = poor" + score);
		}
		

	}
}
