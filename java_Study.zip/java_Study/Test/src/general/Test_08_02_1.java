package general;

import java.util.Scanner;

public class Test_08_02_1 {

	public static void main(String[] args) {
		int num;
		Scanner sc = new Scanner(System.in);
		System.out.println("첫 번째 숫자 입력");
		num = sc.nextInt();
		String error = "삐빅에러입니다";
		
		Object result1 = (0 <= num  || num >= 100) ? num: error ;
		
		System.out.println(result1);

	}

}
