package general;

import java.util.Random;
import java.util.Scanner;

public class Test_08_07 {

	public static void main(String[] args) {

		int a = (int) (Math.random() * 100); // 0-99 사이의 난수

		Random variable1 = new Random();
		int variable2 = variable1.nextInt(100);

		Scanner sc = new Scanner(System.in);

		while (true) {

			System.out.println("내가 만든 쿠키~ 몇번 구우시겠습니까?*숫자입력*:");
			int cuki = sc.nextInt();

			if (cuki > a) {
				System.out.println("너무많이 구웠지");
				continue;
			} else if (cuki < a) {
				System.out.println("아니 지금 반죽 먹으라는거?");
				continue;
			}
			if (cuki == a) {
				System.out.println("영~~차!! 아주 좋아!!! ㅈㄴ 좋아!!");
				break;
			}

		}
	}
}
