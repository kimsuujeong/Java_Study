package general;

import java.util.Scanner;

public class Test_08_02_3 {
	public static void main(String[] args) {

		// 4개의 값을 콘솔에서 입력 받아 처리하시오
		// 조건) 성별 : M 이면 "남자", 나머지는 "여자"
		// 그 외의 값 : 에러
		String name;
		char gender;
		int age;
		double tall;

		Scanner sc = new Scanner(System.in);
		System.out.println("이름");
		name = sc.nextLine();

		System.out.println("성별");
		gender = sc.nextLine().charAt(0);

		System.out.println("나이");
		age = sc.nextInt();

		System.out.println("신장");
		tall = sc.nextDouble();


		System.out.println("이름: " + name);
		System.out.println("성별: " + gender);
		System.out.println("나이: " + age);
		System.out.println("신장: " + tall);

	}
}
