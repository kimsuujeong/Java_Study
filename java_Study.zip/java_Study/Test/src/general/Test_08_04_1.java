package general;

import java.util.Scanner;

public class Test_08_04_1 {
	public static void main(String[] args) {

//		Scanner sc = new Scanner(System.in);
//
//		int 제곱이라우 = 1;
//		System.out.println("x의 값을 입력하시오:");
//		int x = sc.nextInt();
//		System.out.println("y의 값을 입력하시오:");
//		int y = sc.nextInt();
//
////		for (int i = 1; i <= y; i++) {
////			
////			result *= y;
////			
////		}
////			
////			System.out.println(x + "의" + y + "승은" + 제곱이라우);
////			
////		}
//
//		System.out.println(x + "의" + y + "승은 " + (int) Math.pow(x, y));

//		
//		for ( int i = 1; i <=9; i ++) {
//			System.out.println("나는"+i+"단 이라우");
//			for (int j = 1; j<=9; j ++) {
//				int o = i*j;
//				System.out.println(i+"x"+j + "=" + o);
//			}
//		}

//		int [][] test = {
//				{10, 20, 30},
//				{40, 50, 60},
//				{70, 80, 90}
//		};
//		
//		for (int i = 0 ; i < test.length; i++) {
//			for(int j = 0 ; j < test.length; j++) {
//				System.out.println(test[i][j]);
//			}
		
		int[] arr = {1,2,3,4,5};
		for(int a : arr) {
			System.out.println(a);
		}
		
	}

}
