//package general;
//
//import java.util.Scanner;
//
//public class Test_08_02_2 {
//	public static void main(String[] args) {
//
//		Scanner 날짜받아라 = new Scanner(System.in);
//		System.out.println("찾고 싶은 월 숫자를 입력해보셈");
//		int 나날짜임 = 날짜받아라.nextInt();
//
//		if (나날짜임 > 12) {
//			System.out.println(나날짜임 + "월? 님 혹시 이세계에서 오심?ㅋㅋㅋ");
//		} else if (나날짜임 % 2 == 1) {
//			System.out.println(나날짜임 + "월임 31일까지 존버 하셈");
//		} else if (나날짜임 == 2) {
//			System.out.println(나날짜임 + "월임 아 ㅋㅋㅋ 나 특별하다고");
//		} else {
//			System.out.println(나날짜임 + "월임 30일까지 존버 하셈");
//		}
//
//	}
//}