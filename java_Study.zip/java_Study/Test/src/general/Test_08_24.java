package general;

public class Test_08_24 {
	// 주석 달기
	
	// 펠린드롬 -> 같은 숫자가 몇개인지 구하는 문제
	
	static String s = "abcdcba"; // String 타입인 s에 "abcdcba" 넣기

	public static void main(String[] args) {

		System.out.println(findLongestPalindromeLength(s)); // test case -> 결과값 출력함

	}

	public static int findLongestPalindromeLength(String s) {

		int answer = 0;
		int size = s.length(); // size = s의 길이

		for (int i = 0; i < size; i++) {

			int length1 = expandAroundCenter(s, i, i);
			int length2 = expandAroundCenter(s, i, i + 1);
			
			/* length1 :
			 * 서로 같은 값인지 비교하는 것
			 * 
			 * length2 :
			 * i+ 즉, String s의 출력되는 값을 끝까지 출력
			 * */

			int maxLength = Math.max(length1, length2);
			answer = Math.max(answer, maxLength);
			
			// Math.max -> 입력받은 0개 이상의 숫자 중 가장 큰 숫자를 반환
			// 즉, answer -> answer(초기값 0)임으로 1이상의 최대값을 받음
		}

		return answer;
	}

	public static int expandAroundCenter(String s, int left, int right) {
		while (left >= 0 && right < s.length() && s.charAt(left) == s.charAt(right)) {
			left--;
			right++;
			
			// 왼족 값과 오른쪽 값을 차례대로 출력하며 비교하다가 left값과 right 값이 같으면 종료
		}

		return right - left - 1;
	}

}
