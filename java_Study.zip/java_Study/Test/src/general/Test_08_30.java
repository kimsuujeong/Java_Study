package general;

public class Test_08_30 {
	
	public static void main(String[] args) {
		
		System.out.println(); // test case -> n(멀리뛰기에 사용될 칸의 수) 넣어주기
		
	}
	
	public static void gae_jal_ddam(int n) {
		
		int jump1 = 1; // 1번 뛰었을 때
		int jump2 = 2; // 2번 뛰었을 때
		
		for (int jumping_gunchim = 0; jumping_gunchim <= n; jumping_gunchim++) {
			/*
			 * 
			 * */
		}
		
	return;	
	}

}
