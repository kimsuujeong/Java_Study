package general;

import java.util.Scanner;

public class Test_08_09_02 {
	public static void main(String[] args) {
//		1. 곱셈 식을 띄운다 (띄우는 값은 랜덤)
//		2. 좌항 1~20, 우항 1~20
//		난수부터 만들어 보기

		int num1, num2;
		int result = 0;
		int falsCnt = 0;
		

		Scanner sc = new Scanner(System.in);

	 	num1 = (int) (Math.random() * 18) + 2;
		num2 = (int) (Math.random() * 18) + 2;

		System.out.println(("==== 곱셈 스피드 퀴즈! ==="));
		System.out.println(num1 + "*" + num2 + " = ");
		result = sc.nextInt();
		System.out.println("==== 틀리면 빠아아따 ===");

		if (result != (num1 * num2)) {

			System.out.println("너 빠따빠따");

		} else {

			System.out.println("빠따 숨김");

		}

	}

}
