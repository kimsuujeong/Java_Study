package Middle_Test_Exam;

public class Test_04 {

	/*
	 * 두 수와 연산자를 입력 받아 계산하는 프로그램을 작성하시오. (실행 예시) 첫번째 수 입력 : 50 연산자(+, -, *, /, %)
	 * 입력: * 두번째 수 입력 : 22 50 * 22 = 1100
	 */

	public static void main(String[] args) {

	}
}