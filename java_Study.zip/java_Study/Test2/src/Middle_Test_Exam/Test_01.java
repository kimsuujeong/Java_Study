package Middle_Test_Exam;

public class Test_01 {

	public static void main(String[] args) {
		
		// 1부터 100 사이의 정수 중 3의 배수이면서 5의 배수가 아닌 수
		
		for (int i = 1; i <= 100; i++) {
			if (i%3==0 && i%5!=0) {
				System.out.println(i);
			}
		}

	}
}