package Middle_Test_Exam;

import java.util.Scanner;

public class Test_02 {
	
	// 사용자로부터 단을 입력 받아 구구단을 출력하는 프로그램을 작성하시오.
	// 단, 2단 ~ 9단 이외의 단을 입력 받으면, 단을 다시 입력 받는다.


	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		while (true) {
			System.out.print("구구단을 출력할 단을 입력하세요 (2~9): ");

			if (scanner.hasNextInt()) {
				int dan = scanner.nextInt();

				if (dan >= 2 && dan <= 9) {
					for (int i = 1; i <= 9; i++) {
						System.out.println(dan + " x " + i + " = " + (dan * i));
					}
					break;
				} else {
					System.out.println("올바른 숫자를 입력하세요.");
					scanner.next(); // 잘못된 입력을 버림
				}
			}
		}

		scanner.close();
	}
}