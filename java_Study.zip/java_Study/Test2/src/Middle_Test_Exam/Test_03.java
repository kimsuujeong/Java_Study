package Middle_Test_Exam;

public class Test_03 {
	
	//1부터 연속된 정수의 합계를 계산하여, 그 합계가 4000을 넘어가는 순간의 수를 구하여 출력하시오. 
	
	public static void main(String[] args) {
		
		int total = 0;
		int i = 1;
		
		while (i <= 12341234){
			
			total += i;
			
			i++;
			
			if (total > 4000) {
				break;
			}
			
		}
		
		System.out.println(total);
		
	}

}
