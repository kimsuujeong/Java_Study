package Middle_Test_Exam;

import java.util.Scanner;

public class Test_10 {

	public static void main(String[] args) throws Exception {
		
		
		int score = 0;
		Scanner sc = new Scanner(System.in);;

		try {
			
			System.out.println("점수 입력 ");
			score = input(sc.nextInt());
			System.out.println("입력한 점수는 : " + score + "점");

		} catch (ScoreInputException e) {
			
			System.out.println("100 이하 숫자를 입력해주세요");
			e.printStackTrace();

		}

	}

	static int input(int score) throws Exception{
		// TODO Auto-generated method stub
		if (score>100) {
			throw new Exception();
		}
		
		return score;
	}


	public class ScoreInputException extends Exception {

		public ScoreInputException() {
		}

		public ScoreInputException(String message) {
			//super(message); // 부모 클래스 생성자 호출
			System.out.println("숫자가 너무 큽니당");
		}

	}
}
